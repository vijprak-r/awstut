const socket = io();

let chart;
socket.on('pollData', (data) => {
    document.getElementById('question').innerText = data.question;

    // Render voting buttons
    const optionsDiv = document.getElementById('options');
    optionsDiv.innerHTML = '';
    data.options.forEach((option, index) => {
        const btn = document.createElement('button');
        btn.innerText = option;
        btn.onclick = () => socket.emit('newVote', index);
        optionsDiv.appendChild(btn);
    });

    // Update chart
    if (!chart) {
        const ctx = document.getElementById('pollChart').getContext('2d');
        chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.options,
                datasets: [{
                    label: '# of Votes',
                    data: data.votes,
                    borderWidth: 1
                }]
            },
            options: { scales: { y: { beginAtZero: true } } }
        });
    } else {
        chart.data.labels = data.options;
        chart.data.datasets[0].data = data.votes;
        chart.update();
    }
});
