const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

let pollQuestion = "What is your favorite programming language?";
let options = ["Python", "Java", "C++", "JavaScript"];
let votes = [0, 0, 0, 0];

app.use(express.static(path.join(__dirname, 'public')));

io.on('connection', (socket) => {
    console.log('A user connected');

    // Send current poll state to new user
    socket.emit('pollData', { question: pollQuestion, options, votes });

    // Handle new vote
    socket.on('newVote', (index) => {
        if (typeof index === 'number' && index >=0 && index < votes.length) {
            votes[index]++;
            io.emit('pollData', { question: pollQuestion, options, votes });
        }
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

const port = process.env.PORT || 3000;
server.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
