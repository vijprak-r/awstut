const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// In-memory state
const rooms = new Map(); // roomName -> Set of usernames
const userMeta = new Map(); // socket.id -> { username, room }

io.on("connection", (socket) => {
  // send available rooms
  socket.emit("rooms:list", Array.from(rooms.keys()));

  socket.on("user:join", ({ username, room }) => {
    // leave previous if any
    const prev = userMeta.get(socket.id);
    if (prev && prev.room) {
      socket.leave(prev.room);
      if (rooms.has(prev.room)) {
        rooms.get(prev.room).delete(prev.username);
        io.to(prev.room).emit("room:users", Array.from(rooms.get(prev.room) || []));
        io.to(prev.room).emit("sysmsg", `${prev.username} left ${prev.room}`);
        if (rooms.get(prev.room).size === 0) {
          rooms.delete(prev.room);
          io.emit("rooms:list", Array.from(rooms.keys()));
        }
      }
    }

    // join the new room
    socket.join(room);
    if (!rooms.has(room)) rooms.set(room, new Set());
    rooms.get(room).add(username);
    userMeta.set(socket.id, { username, room });
    io.emit("rooms:list", Array.from(rooms.keys()));
    io.to(room).emit("room:users", Array.from(rooms.get(room)));
    io.to(room).emit("sysmsg", `${username} joined ${room} 🎉`);
  });

  socket.on("chat:message", (text) => {
    const meta = userMeta.get(socket.id);
    if (!meta) return;
    const payload = { user: meta.username, text, ts: Date.now() };
    io.to(meta.room).emit("chat:message", payload);
  });

  socket.on("chat:typing", (isTyping) => {
    const meta = userMeta.get(socket.id);
    if (!meta) return;
    socket.to(meta.room).emit("chat:typing", { user: meta.username, isTyping });
  });

  socket.on("disconnect", () => {
    const meta = userMeta.get(socket.id);
    if (!meta) return;
    const { username, room } = meta;
    if (rooms.has(room)) {
      rooms.get(room).delete(username);
      io.to(room).emit("room:users", Array.from(rooms.get(room)));
      io.to(room).emit("sysmsg", `${username} disconnected`);
      if (rooms.get(room).size === 0) {
        rooms.delete(room);
        io.emit("rooms:list", Array.from(rooms.keys()));
      }
    }
    userMeta.delete(socket.id);
  });
});

server.listen(process.env.PORT || 3000, () => {
  console.log("Server running on port", process.env.PORT || 3000);
});
